/*
  # Create AI Assistant Tables

  1. New Tables
    - `ai_conversations`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to users)
      - `title` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `last_message_at` (timestamp)
      - `message_count` (integer)
    
    - `ai_messages`
      - `id` (uuid, primary key)
      - `conversation_id` (uuid, foreign key to ai_conversations)
      - `role` (text, 'user' or 'assistant')
      - `content` (text)
      - `timestamp` (timestamp)
      - `metadata` (jsonb)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to manage their own conversations and messages
    - Add trigger for updating updated_at timestamp

  3. Indexes
    - Add indexes for performance on common queries
*/

-- Create ai_conversations table
CREATE TABLE IF NOT EXISTS ai_conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title text NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL,
  last_message_at timestamptz DEFAULT now() NOT NULL,
  message_count integer DEFAULT 0 NOT NULL
);

-- Create ai_messages table
CREATE TABLE IF NOT EXISTS ai_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES ai_conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  timestamp timestamptz DEFAULT now() NOT NULL,
  metadata jsonb
);

-- Enable RLS
ALTER TABLE ai_conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE ai_messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for ai_conversations
CREATE POLICY "Users can manage own conversations"
  ON ai_conversations
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Create RLS policies for ai_messages
CREATE POLICY "Users can manage messages in own conversations"
  ON ai_messages
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM ai_conversations 
      WHERE id = conversation_id AND user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM ai_conversations 
      WHERE id = conversation_id AND user_id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_ai_conversations_user_id 
  ON ai_conversations(user_id);

CREATE INDEX IF NOT EXISTS idx_ai_conversations_last_message 
  ON ai_conversations(user_id, last_message_at DESC);

CREATE INDEX IF NOT EXISTS idx_ai_messages_conversation_id 
  ON ai_messages(conversation_id);

CREATE INDEX IF NOT EXISTS idx_ai_messages_timestamp 
  ON ai_messages(conversation_id, timestamp);

-- Create trigger for updating updated_at timestamp
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'update_ai_conversations_updated_at'
  ) THEN
    CREATE TRIGGER update_ai_conversations_updated_at
      BEFORE UPDATE ON ai_conversations
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;