/*
# Fix PRIMARY KEY issue in schema

1. New Migration
   - Fixes the "multiple PRIMARY KEYs for table ai_conversations" error
   - Maintains all the same tables, functions, and policies as the original schema
   - Ensures only one PRIMARY KEY constraint per table

2. Changes
   - Removed duplicate PRIMARY KEY definitions
   - Maintained all other constraints and policies
*/

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

COMMENT ON SCHEMA "public" IS 'standard public schema';

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";

CREATE OR REPLACE FUNCTION "public"."cleanup_expired_otp_codes"() RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  DELETE FROM auth_otp_codes 
  WHERE expires_at < now() - interval '1 hour';
END;
$$;

ALTER FUNCTION "public"."cleanup_expired_otp_codes"() OWNER TO "postgres";

CREATE OR REPLACE FUNCTION "public"."cleanup_expired_sessions"() RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  DELETE FROM auth_sessions 
  WHERE expires_at < now();
END;
$$;

ALTER FUNCTION "public"."cleanup_expired_sessions"() OWNER TO "postgres";

CREATE OR REPLACE FUNCTION "public"."get_current_auth_user_id"() RETURNS "uuid"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$
  SELECT COALESCE(
    current_setting('app.current_user_id', true)::uuid,
    NULL
  );
$$;

ALTER FUNCTION "public"."get_current_auth_user_id"() OWNER TO "postgres";

CREATE OR REPLACE FUNCTION "public"."update_auth_users_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

ALTER FUNCTION "public"."update_auth_users_updated_at"() OWNER TO "postgres";

CREATE OR REPLACE FUNCTION "public"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

ALTER FUNCTION "public"."update_updated_at_column"() OWNER TO "postgres";

SET default_tablespace = '';
SET default_table_access_method = "heap";

CREATE TABLE IF NOT EXISTS "public"."ai_conversations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_message_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "message_count" integer DEFAULT 0 NOT NULL,
    PRIMARY KEY ("id")
);

ALTER TABLE "public"."ai_conversations" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."allergies" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "type" "text" NOT NULL,
    "severity" "text" NOT NULL,
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    PRIMARY KEY ("id")
);

ALTER TABLE "public"."allergies" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."ai_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "conversation_id" "uuid" NOT NULL,
    "role" "text" NOT NULL,
    "content" "text" NOT NULL,
    "timestamp" timestamp with time zone DEFAULT "now"() NOT NULL,
    "metadata" "jsonb",
    PRIMARY KEY ("id"),
    CONSTRAINT "ai_messages_role_check" CHECK (("role" = ANY (ARRAY['user'::"text", 'assistant'::"text"])))
);

ALTER TABLE "public"."ai_messages" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."appointment_chains" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "chain_name" "text" NOT NULL,
    "root_appointment_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id")
);

ALTER TABLE "public"."appointment_chains" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."appointment_documents" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "appointment_id" "uuid" NOT NULL,
    "document_id" "uuid" NOT NULL,
    "linked_at" timestamp with time zone DEFAULT "now"()
);

ALTER TABLE "public"."appointment_documents" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."appointments" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "title" "text" NOT NULL,
    "appointment_type" "text" NOT NULL,
    "appointment_date" "date" NOT NULL,
    "appointment_time" time without time zone NOT NULL,
    "status" "text" DEFAULT 'scheduled'::"text",
    "reminder_24h_sent" boolean DEFAULT false,
    "reminder_1h_sent" boolean DEFAULT false,
    "is_recurring" boolean DEFAULT false,
    "recurrence_pattern" "text",
    "recurrence_end_date" "date",
    "parent_appointment_id" "uuid",
    "location_name" "text",
    "location_address" "text",
    "location_phone" "text",
    "location_coordinates" "point",
    "doctor_name" "text",
    "doctor_specialization" "text",
    "lab_name" "text",
    "test_name" "text",
    "referring_doctor" "text",
    "previous_appointment_id" "uuid",
    "notes" "text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id"),
    CONSTRAINT "appointments_appointment_type_check" CHECK (("appointment_type" = ANY (ARRAY['consultation'::"text", 'test'::"text", 'followup'::"text"]))),
    CONSTRAINT "appointments_status_check" CHECK (("status" = ANY (ARRAY['scheduled'::"text", 'completed'::"text", 'cancelled'::"text", 'rescheduled'::"text"])))
);

ALTER TABLE "public"."appointments" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."auth_otp_codes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text" NOT NULL,
    "code" "text" NOT NULL,
    "purpose" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "used_at" timestamp with time zone,
    "attempts" integer DEFAULT 0,
    "max_attempts" integer DEFAULT 3,
    "created_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id"),
    CONSTRAINT "auth_otp_codes_purpose_check" CHECK (("purpose" = ANY (ARRAY['signup'::"text", 'signin'::"text", 'password_reset'::"text"])))
);

ALTER TABLE "public"."auth_otp_codes" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."auth_sessions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token" "text" NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "last_used_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id")
);

ALTER TABLE "public"."auth_sessions" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."auth_users" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text" NOT NULL,
    "password_hash" "text",
    "first_name" "text" NOT NULL,
    "last_name" "text" NOT NULL,
    "phone" "text",
    "email_verified" boolean DEFAULT false,
    "is_active" boolean DEFAULT true,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id")
);

ALTER TABLE "public"."auth_users" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."caregiver_access" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "caregiver_id" "uuid" NOT NULL,
    "relationship_type" "text" NOT NULL,
    "documents_access" "text" DEFAULT 'none'::"text",
    "medications_access" "text" DEFAULT 'none'::"text",
    "appointments_access" "text" DEFAULT 'none'::"text",
    "mood_tracker_access" "text" DEFAULT 'none'::"text",
    "progress_tracker_access" "text" DEFAULT 'none'::"text",
    "emergency_info_access" "text" DEFAULT 'none'::"text",
    "status" "text" DEFAULT 'active'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id"),
    CONSTRAINT "caregiver_access_appointments_access_check" CHECK (("appointments_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_documents_access_check" CHECK (("documents_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_emergency_info_access_check" CHECK (("emergency_info_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_medications_access_check" CHECK (("medications_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_mood_tracker_access_check" CHECK (("mood_tracker_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_progress_tracker_access_check" CHECK (("progress_tracker_access" = ANY (ARRAY['none'::"text", 'view'::"text", 'full'::"text"]))),
    CONSTRAINT "caregiver_access_status_check" CHECK (("status" = ANY (ARRAY['active'::"text", 'inactive'::"text", 'revoked'::"text"])))
);

ALTER TABLE "public"."caregiver_access" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."caregivers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "email" "text" NOT NULL,
    "name" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "address" "text" NOT NULL,
    "caregiver_type" "text" NOT NULL,
    "is_verified" boolean DEFAULT false,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id"),
    CONSTRAINT "caregivers_caregiver_type_check" CHECK (("caregiver_type" = ANY (ARRAY['doctor'::"text", 'nurse'::"text", 'family'::"text"])))
);

ALTER TABLE "public"."caregivers" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."documents" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "file_name" "text" NOT NULL,
    "file_path" "text" NOT NULL,
    "file_size" bigint NOT NULL,
    "file_type" "text" NOT NULL,
    "document_type" "text" NOT NULL,
    "document_name" "text" NOT NULL,
    "doctor_name" "text",
    "report_date" "date",
    "report_center" "text",
    "upload_date" timestamp with time zone DEFAULT "now"(),
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    PRIMARY KEY ("id"),
    CONSTRAINT "documents_document_type_check" CHECK (("document_type" = ANY (ARRAY['Report'::"text", 'Prescription'::"text"])))
);

ALTER TABLE "public"."documents" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."emergency_contacts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "relationship" "text" NOT NULL,
    "phone" "text" NOT NULL,
    "email" "text",
    "is_primary" boolean DEFAULT false,
    "can_access_records" boolean DEFAULT false,
    PRIMARY KEY ("id"),
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"()
);

ALTER TABLE "public"."emergency_contacts" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."health_metrics" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "metric_type" "text" NOT NULL,
    "value" numeric(8,2) NOT NULL,
    "unit" "text" NOT NULL,
    "recorded_at" timestamp with time zone DEFAULT "now"(),
    "notes" "text",
    "source" "text" DEFAULT 'manual'::"text",
    PRIMARY KEY ("id"),
    CONSTRAINT "health_metrics_metric_type_check" CHECK (("metric_type" = ANY (ARRAY['weight'::"text", 'blood_pressure_systolic'::"text", 'blood_pressure_diastolic'::"text", 'heart_rate'::"text", 'blood_sugar'::"text", 'temperature'::"text", 'sleep_duration'::"text", 'exercise_duration'::"text", 'calories_burned'::"text"]))),
    CONSTRAINT "health_metrics_source_check" CHECK (("source" = ANY (ARRAY['manual'::"text", 'device'::"text", 'report'::"text"])))
);

ALTER TABLE "public"."health_metrics" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."medication_intakes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "medication_id" "uuid" NOT NULL,
    "taken_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "scheduled_time" "text" NOT NULL,
    "notes" "text",
    PRIMARY KEY ("id"),
    "created_at" timestamp with time zone DEFAULT "now"()
);

ALTER TABLE "public"."medication_intakes" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."medications" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "dosage" "text" NOT NULL,
    "frequency" "text" NOT NULL,
    "time_of_day" "text"[] NOT NULL,
    "start_date" "date" DEFAULT CURRENT_DATE NOT NULL,
    "end_date" "date",
    "instructions" "text",
    "is_active" boolean DEFAULT true,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "doctor_name" "text",
    PRIMARY KEY ("id"),
    CONSTRAINT "medications_date_range_check" CHECK ((("end_date" IS NULL) OR ("end_date" >= "start_date"))),
    CONSTRAINT "medications_start_date_check" CHECK (("start_date" <= (CURRENT_DATE + '30 days'::interval))),
    CONSTRAINT "medications_time_of_day_check" CHECK (("array_length"("time_of_day", 1) > 0))
);

ALTER TABLE "public"."medications" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."mood_entries" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "mood" "text" NOT NULL,
    "mood_score" integer NOT NULL,
    "notes" "text",
    "energy_level" integer,
    "sleep_quality" integer,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "stress_level" integer DEFAULT 5 NOT NULL,
    "tags" "text"[],
    PRIMARY KEY ("id"),
    CONSTRAINT "mood_entries_energy_level_check" CHECK ((("energy_level" >= 1) AND ("energy_level" <= 5))),
    CONSTRAINT "mood_entries_mood_check" CHECK (("mood" = ANY (ARRAY['excellent'::"text", 'good'::"text", 'neutral'::"text", 'stressed'::"text", 'distressed'::"text"]))),
    CONSTRAINT "mood_entries_mood_score_check" CHECK ((("mood_score" >= 1) AND ("mood_score" <= 5))),
    CONSTRAINT "mood_entries_sleep_quality_check" CHECK ((("sleep_quality" >= 1) AND ("sleep_quality" <= 5))),
    CONSTRAINT "mood_entries_stress_level_check" CHECK ((("stress_level" >= 1) AND ("stress_level" <= 10)))
);

ALTER TABLE "public"."mood_entries" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."sos_alerts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "emergency_info" "jsonb" NOT NULL,
    "caregiver_ids" "uuid"[] DEFAULT '{}'::"uuid"[] NOT NULL,
    "status" "text" DEFAULT 'sent'::"text" NOT NULL,
    "location_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "resolved_at" timestamp with time zone,
    "notes" "text",
    PRIMARY KEY ("id"),
    CONSTRAINT "sos_alerts_status_check" CHECK (("status" = ANY (ARRAY['sent'::"text", 'acknowledged'::"text", 'resolved'::"text", 'false_alarm'::"text"])))
);

ALTER TABLE "public"."sos_alerts" OWNER TO "postgres";

CREATE TABLE IF NOT EXISTS "public"."user_profiles" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "first_name" "text" NOT NULL,
    "last_name" "text" NOT NULL,
    "phone" "text",
    "date_of_birth" "date",
    "height_cm" integer,
    "weight_kg" numeric(5,2),
    "blood_type" "text",
    "allergies" "text"[],
    "medical_conditions" "text"[],
    "emergency_contact_name" "text",
    "emergency_contact_phone" "text",
    "wellness_score_physical" integer DEFAULT 75,
    "wellness_score_mental" integer DEFAULT 75,
    "timezone" "text" DEFAULT 'UTC'::"text",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "address" "text",
    "weight_goal" numeric(5,2),
    "exercise_duration_goal" integer,
    "calories_goal" integer,
    "auth_user_id" "uuid",
    PRIMARY KEY ("id"),
    CONSTRAINT "user_profiles_calories_goal_check" CHECK ((("calories_goal" IS NULL) OR (("calories_goal" >= 50) AND ("calories_goal" <= 2000)))),
    CONSTRAINT "user_profiles_exercise_duration_goal_check" CHECK ((("exercise_duration_goal" IS NULL) OR (("exercise_duration_goal" >= 5) AND ("exercise_duration_goal" <= 300)))),
    CONSTRAINT "user_profiles_weight_goal_check" CHECK ((("weight_goal" IS NULL) OR (("weight_goal" >= (30)::numeric) AND ("weight_goal" <= (300)::numeric))))
);

ALTER TABLE "public"."user_profiles" OWNER TO "postgres";

-- Unique constraints
ALTER TABLE ONLY "public"."appointment_documents"
    ADD CONSTRAINT "appointment_documents_appointment_id_document_id_key" UNIQUE ("appointment_id", "document_id");

ALTER TABLE ONLY "public"."auth_sessions"
    ADD CONSTRAINT "auth_sessions_token_key" UNIQUE ("token");

ALTER TABLE ONLY "public"."auth_users"
    ADD CONSTRAINT "auth_users_email_key" UNIQUE ("email");

ALTER TABLE ONLY "public"."caregiver_access"
    ADD CONSTRAINT "caregiver_access_user_id_caregiver_id_key" UNIQUE ("user_id", "caregiver_id");

ALTER TABLE ONLY "public"."caregivers"
    ADD CONSTRAINT "caregivers_email_key" UNIQUE ("email");

ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_unique" UNIQUE ("user_id");

-- Indexes
CREATE INDEX "idx_ai_conversations_last_message" ON "public"."ai_conversations" USING "btree" ("user_id", "last_message_at" DESC);
CREATE INDEX "idx_ai_conversations_user_id" ON "public"."ai_conversations" USING "btree" ("user_id");
CREATE INDEX "idx_allergies_user_id" ON "public"."allergies" USING "btree" ("user_id");
CREATE INDEX "idx_ai_messages_conversation_id" ON "public"."ai_messages" USING "btree" ("conversation_id");
CREATE INDEX "idx_ai_messages_timestamp" ON "public"."ai_messages" USING "btree" ("conversation_id", "timestamp");
CREATE INDEX "idx_appointment_chains_user" ON "public"."appointment_chains" USING "btree" ("user_id");
CREATE INDEX "idx_appointment_documents_appointment" ON "public"."appointment_documents" USING "btree" ("appointment_id");
CREATE INDEX "idx_appointments_recurring" ON "public"."appointments" USING "btree" ("user_id", "is_recurring");
CREATE INDEX "idx_appointments_reminders" ON "public"."appointments" USING "btree" ("appointment_date", "appointment_time", "status") WHERE ("status" = 'scheduled'::"text");
CREATE INDEX "idx_appointments_status" ON "public"."appointments" USING "btree" ("user_id", "status");
CREATE INDEX "idx_appointments_type" ON "public"."appointments" USING "btree" ("user_id", "appointment_type");
CREATE INDEX "idx_appointments_user_date" ON "public"."appointments" USING "btree" ("user_id", "appointment_date");
CREATE INDEX "idx_auth_otp_code" ON "public"."auth_otp_codes" USING "btree" ("code");
CREATE INDEX "idx_auth_otp_codes_code" ON "public"."auth_otp_codes" USING "btree" ("code");
CREATE INDEX "idx_auth_otp_codes_email" ON "public"."auth_otp_codes" USING "btree" ("email");
CREATE INDEX "idx_auth_otp_codes_expires" ON "public"."auth_otp_codes" USING "btree" ("expires_at");
CREATE INDEX "idx_auth_otp_email" ON "public"."auth_otp_codes" USING "btree" ("email");
CREATE INDEX "idx_auth_otp_expires" ON "public"."auth_otp_codes" USING "btree" ("expires_at");
CREATE INDEX "idx_auth_sessions_expires" ON "public"."auth_sessions" USING "btree" ("expires_at");
CREATE INDEX "idx_auth_sessions_token" ON "public"."auth_sessions" USING "btree" ("token");
CREATE INDEX "idx_auth_sessions_user" ON "public"."auth_sessions" USING "btree" ("user_id");
CREATE INDEX "idx_auth_sessions_user_id" ON "public"."auth_sessions" USING "btree" ("user_id");
CREATE INDEX "idx_auth_users_active" ON "public"."auth_users" USING "btree" ("is_active");
CREATE INDEX "idx_auth_users_email" ON "public"."auth_users" USING "btree" ("email");
CREATE INDEX "idx_caregiver_access_caregiver_id" ON "public"."caregiver_access" USING "btree" ("caregiver_id");
CREATE INDEX "idx_caregiver_access_status" ON "public"."caregiver_access" USING "btree" ("status");
CREATE INDEX "idx_caregiver_access_user_id" ON "public"."caregiver_access" USING "btree" ("user_id");
CREATE INDEX "idx_caregivers_email" ON "public"."caregivers" USING "btree" ("email");
CREATE INDEX "idx_caregivers_type" ON "public"."caregivers" USING "btree" ("caregiver_type");
CREATE INDEX "idx_documents_type" ON "public"."documents" USING "btree" ("user_id", "document_type");
CREATE INDEX "idx_documents_upload_date" ON "public"."documents" USING "btree" ("user_id", "upload_date" DESC);
CREATE INDEX "idx_documents_user_id" ON "public"."documents" USING "btree" ("user_id");
CREATE INDEX "idx_emergency_contacts_user_id" ON "public"."emergency_contacts" USING "btree" ("user_id");
CREATE INDEX "idx_health_metrics_type" ON "public"."health_metrics" USING "btree" ("user_id", "metric_type");
CREATE INDEX "idx_health_metrics_user_id" ON "public"."health_metrics" USING "btree" ("user_id");
CREATE INDEX "idx_medication_intakes_medication_id" ON "public"."medication_intakes" USING "btree" ("medication_id");
CREATE INDEX "idx_medication_intakes_schedule" ON "public"."medication_intakes" USING "btree" ("medication_id", "scheduled_time", "taken_at");
CREATE INDEX "idx_medication_intakes_taken_at" ON "public"."medication_intakes" USING "btree" ("user_id", "taken_at" DESC);
CREATE INDEX "idx_medication_intakes_user_id" ON "public"."medication_intakes" USING "btree" ("user_id");
CREATE INDEX "idx_medications_active" ON "public"."medications" USING "btree" ("user_id", "is_active");
CREATE INDEX "idx_medications_user_id" ON "public"."medications" USING "btree" ("user_id");
CREATE INDEX "idx_mood_entries_date" ON "public"."mood_entries" USING "btree" ("user_id", "created_at");
CREATE INDEX "idx_mood_entries_user_id" ON "public"."mood_entries" USING "btree" ("user_id");
CREATE INDEX "idx_sos_alerts_caregiver_ids" ON "public"."sos_alerts" USING "gin" ("caregiver_ids");
CREATE INDEX "idx_sos_alerts_created_at" ON "public"."sos_alerts" USING "btree" ("user_id", "created_at" DESC);
CREATE INDEX "idx_sos_alerts_status" ON "public"."sos_alerts" USING "btree" ("status");
CREATE INDEX "idx_sos_alerts_user_id" ON "public"."sos_alerts" USING "btree" ("user_id");
CREATE INDEX "idx_user_profiles_auth_user_id" ON "public"."user_profiles" USING "btree" ("auth_user_id");
CREATE INDEX "idx_user_profiles_user_id" ON "public"."user_profiles" USING "btree" ("user_id");

-- Triggers
CREATE OR REPLACE TRIGGER "update_ai_conversations_updated_at" BEFORE UPDATE ON "public"."ai_conversations" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_ai_conversations_updated_at" BEFORE UPDATE ON "public"."allergies" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_appointments_updated_at" BEFORE UPDATE ON "public"."appointments" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_auth_users_updated_at" BEFORE UPDATE ON "public"."auth_users" FOR EACH ROW EXECUTE FUNCTION "public"."update_auth_users_updated_at"();
CREATE OR REPLACE TRIGGER "update_caregiver_access_updated_at" BEFORE UPDATE ON "public"."caregiver_access" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_caregivers_updated_at" BEFORE UPDATE ON "public"."caregivers" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_documents_updated_at" BEFORE UPDATE ON "public"."documents" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_emergency_contacts_updated_at" BEFORE UPDATE ON "public"."emergency_contacts" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_medications_updated_at" BEFORE UPDATE ON "public"."medications" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();
CREATE OR REPLACE TRIGGER "update_user_profiles_updated_at" BEFORE UPDATE ON "public"."user_profiles" FOR EACH ROW EXECUTE FUNCTION "public"."update_updated_at_column"();

-- Foreign Keys
-- Note: We're using auth.users for some foreign keys, which will need to be updated if using custom auth
ALTER TABLE ONLY "public"."ai_messages"
    ADD CONSTRAINT "ai_messages_conversation_id_fkey" FOREIGN KEY ("conversation_id") REFERENCES "public"."ai_conversations"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointment_chains"
    ADD CONSTRAINT "appointment_chains_root_appointment_id_fkey" FOREIGN KEY ("root_appointment_id") REFERENCES "public"."appointments"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointment_documents"
    ADD CONSTRAINT "appointment_documents_appointment_id_fkey" FOREIGN KEY ("appointment_id") REFERENCES "public"."appointments"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointment_documents"
    ADD CONSTRAINT "appointment_documents_document_id_fkey" FOREIGN KEY ("document_id") REFERENCES "public"."documents"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_parent_appointment_id_fkey" FOREIGN KEY ("parent_appointment_id") REFERENCES "public"."appointments"("id") ON DELETE SET NULL;

ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_previous_appointment_id_fkey" FOREIGN KEY ("previous_appointment_id") REFERENCES "public"."appointments"("id") ON DELETE SET NULL;

ALTER TABLE ONLY "public"."auth_sessions"
    ADD CONSTRAINT "auth_sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."caregiver_access"
    ADD CONSTRAINT "caregiver_access_caregiver_id_fkey" FOREIGN KEY ("caregiver_id") REFERENCES "public"."caregivers"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."medication_intakes"
    ADD CONSTRAINT "medication_intakes_medication_id_fkey" FOREIGN KEY ("medication_id") REFERENCES "public"."medications"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_auth_user_id_fkey" FOREIGN KEY ("auth_user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

-- RLS Policies
CREATE POLICY "Allow OTP operations" ON "public"."auth_otp_codes" TO "authenticated", "anon" USING (true) WITH CHECK (true);
CREATE POLICY "Allow authenticated users to delete caregivers" ON "public"."caregivers" FOR DELETE TO "authenticated", "anon" USING (true);
CREATE POLICY "Allow authenticated users to insert caregivers" ON "public"."caregivers" FOR INSERT TO "authenticated", "anon" WITH CHECK (true);
CREATE POLICY "Allow authenticated users to select caregivers" ON "public"."caregivers" FOR SELECT TO "authenticated", "anon" USING (true);
CREATE POLICY "Allow authenticated users to update caregivers" ON "public"."caregivers" FOR UPDATE TO "authenticated", "anon" USING (true) WITH CHECK (true);
CREATE POLICY "Allow session creation" ON "public"."auth_sessions" FOR INSERT TO "authenticated", "anon" WITH CHECK (true);
CREATE POLICY "Allow signup for anonymous users" ON "public"."auth_users" FOR INSERT TO "anon" WITH CHECK (true);
CREATE POLICY "Caregivers can view SOS alerts they're notified about" ON "public"."sos_alerts" FOR SELECT TO "authenticated", "anon" USING ((EXISTS ( SELECT 1 FROM "public"."caregiver_access" "ca" WHERE (("ca"."caregiver_id" = ANY ("sos_alerts"."caregiver_ids")) AND ("ca"."status" = 'active'::"text") AND ("ca"."emergency_info_access" <> 'none'::"text")))));
CREATE POLICY "Enable read access for all users" ON "public"."auth_users" FOR SELECT USING (true);
CREATE POLICY "Users can delete own sessions" ON "public"."auth_sessions" FOR DELETE USING (true);
CREATE POLICY "Users can delete related caregivers" ON "public"."caregivers" FOR DELETE TO "authenticated", "anon" USING ((EXISTS ( SELECT 1 FROM "public"."caregiver_access" WHERE (("caregiver_access"."caregiver_id" = "caregivers"."id") AND ("caregiver_access"."user_id" = "auth"."uid"())))));
CREATE POLICY "Users can manage messages in own conversations" ON "public"."ai_messages" TO "authenticated", "anon" USING (true) WITH CHECK (EXISTS ( SELECT 1 FROM "public"."ai_conversations"));
CREATE POLICY "Users can manage own SOS alerts" ON "public"."sos_alerts" TO "authenticated" , "anon" USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage own appointment chains" ON "public"."appointment_chains" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own appointment documents" ON "public"."appointment_documents" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own appointments" ON "public"."appointments" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own conversations" ON "public"."ai_conversations" TO "authenticated", "anon" USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage own allergies" ON "public"."allergies" TO "authenticated", "anon" USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage own documents" ON "public"."documents" TO "authenticated" , "anon" USING (true);
CREATE POLICY "Users can manage own emergency contacts" ON "public"."emergency_contacts" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own health metrics" ON "public"."health_metrics" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own medication intakes" ON "public"."medication_intakes" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own medications" ON "public"."medications" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage own mood entries" ON "public"."mood_entries" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can manage their caregiver access" ON "public"."caregiver_access" TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can read own data" ON "public"."auth_users" FOR SELECT USING (true);
CREATE POLICY "Users can read own sessions" ON "public"."auth_sessions" FOR SELECT USING (true);
CREATE POLICY "Users can update own data" ON "public"."auth_users" FOR UPDATE USING (true);
CREATE POLICY "Users can update related caregivers" ON "public"."caregivers" FOR UPDATE TO "authenticated", "anon" USING (true) ;
CREATE POLICY "Users can view own sessions" ON "public"."auth_sessions" FOR SELECT USING (true);
CREATE POLICY "Users can view related caregivers" ON "public"."caregivers" FOR SELECT TO "authenticated", "anon" USING (true) ;
CREATE POLICY "Users can insert own profile" ON "public"."user_profiles" FOR INSERT TO "authenticated", "anon" WITH CHECK (true);
CREATE POLICY "Users can update own profile" ON "public"."user_profiles" FOR UPDATE  TO "authenticated", "anon" USING (true);
CREATE POLICY "Users can view own profile" ON "public"."user_profiles" FOR SELECT TO "authenticated", "anon" USING (true);

-- Enable Row Level Security
ALTER TABLE "public"."ai_conversations" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."allergies" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."ai_messages" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."appointment_chains" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."appointment_documents" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."appointments" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."auth_otp_codes" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."auth_sessions" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."auth_users" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."caregiver_access" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."caregivers" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."documents" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."emergency_contacts" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."health_metrics" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."medication_intakes" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."medications" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."mood_entries" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."sos_alerts" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "public"."user_profiles" ENABLE ROW LEVEL SECURITY;

-- Grants
GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";

GRANT ALL ON FUNCTION "public"."cleanup_expired_otp_codes"() TO "anon";
GRANT ALL ON FUNCTION "public"."cleanup_expired_otp_codes"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."cleanup_expired_otp_codes"() TO "service_role";

GRANT ALL ON FUNCTION "public"."cleanup_expired_sessions"() TO "anon";
GRANT ALL ON FUNCTION "public"."cleanup_expired_sessions"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."cleanup_expired_sessions"() TO "service_role";

GRANT ALL ON FUNCTION "public"."get_current_auth_user_id"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_current_auth_user_id"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_current_auth_user_id"() TO "service_role";

GRANT ALL ON FUNCTION "public"."update_auth_users_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_auth_users_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_auth_users_updated_at"() TO "service_role";

GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "anon";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."update_updated_at_column"() TO "service_role";

GRANT ALL ON TABLE "public"."ai_conversations" TO "anon";
GRANT ALL ON TABLE "public"."ai_conversations" TO "authenticated";
GRANT ALL ON TABLE "public"."ai_conversations" TO "service_role";
GRANT ALL ON TABLE "public"."allergies" TO "anon";
GRANT ALL ON TABLE "public"."allergies" TO "authenticated";
GRANT ALL ON TABLE "public"."allergies" TO "service_role";

GRANT ALL ON TABLE "public"."ai_messages" TO "anon";
GRANT ALL ON TABLE "public"."ai_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."ai_messages" TO "service_role";

GRANT ALL ON TABLE "public"."appointment_chains" TO "anon";
GRANT ALL ON TABLE "public"."appointment_chains" TO "authenticated";
GRANT ALL ON TABLE "public"."appointment_chains" TO "service_role";

GRANT ALL ON TABLE "public"."appointment_documents" TO "anon";
GRANT ALL ON TABLE "public"."appointment_documents" TO "authenticated";
GRANT ALL ON TABLE "public"."appointment_documents" TO "service_role";

GRANT ALL ON TABLE "public"."appointments" TO "anon";
GRANT ALL ON TABLE "public"."appointments" TO "authenticated";
GRANT ALL ON TABLE "public"."appointments" TO "service_role";

GRANT ALL ON TABLE "public"."auth_otp_codes" TO "anon";
GRANT ALL ON TABLE "public"."auth_otp_codes" TO "authenticated";
GRANT ALL ON TABLE "public"."auth_otp_codes" TO "service_role";

GRANT ALL ON TABLE "public"."auth_sessions" TO "anon";
GRANT ALL ON TABLE "public"."auth_sessions" TO "authenticated";
GRANT ALL ON TABLE "public"."auth_sessions" TO "service_role";

GRANT ALL ON TABLE "public"."auth_users" TO "anon";
GRANT ALL ON TABLE "public"."auth_users" TO "authenticated";
GRANT ALL ON TABLE "public"."auth_users" TO "service_role";

GRANT ALL ON TABLE "public"."caregiver_access" TO "anon";
GRANT ALL ON TABLE "public"."caregiver_access" TO "authenticated";
GRANT ALL ON TABLE "public"."caregiver_access" TO "service_role";

GRANT ALL ON TABLE "public"."caregivers" TO "anon";
GRANT ALL ON TABLE "public"."caregivers" TO "authenticated";
GRANT ALL ON TABLE "public"."caregivers" TO "service_role";

GRANT ALL ON TABLE "public"."documents" TO "anon";
GRANT ALL ON TABLE "public"."documents" TO "authenticated";
GRANT ALL ON TABLE "public"."documents" TO "service_role";

GRANT ALL ON TABLE "public"."emergency_contacts" TO "anon";
GRANT ALL ON TABLE "public"."emergency_contacts" TO "authenticated";
GRANT ALL ON TABLE "public"."emergency_contacts" TO "service_role";

GRANT ALL ON TABLE "public"."health_metrics" TO "anon";
GRANT ALL ON TABLE "public"."health_metrics" TO "authenticated";
GRANT ALL ON TABLE "public"."health_metrics" TO "service_role";

GRANT ALL ON TABLE "public"."medication_intakes" TO "anon";
GRANT ALL ON TABLE "public"."medication_intakes" TO "authenticated";
GRANT ALL ON TABLE "public"."medication_intakes" TO "service_role";

GRANT ALL ON TABLE "public"."medications" TO "anon";
GRANT ALL ON TABLE "public"."medications" TO "authenticated";
GRANT ALL ON TABLE "public"."medications" TO "service_role";

GRANT ALL ON TABLE "public"."mood_entries" TO "anon";
GRANT ALL ON TABLE "public"."mood_entries" TO "authenticated";
GRANT ALL ON TABLE "public"."mood_entries" TO "service_role";

GRANT ALL ON TABLE "public"."sos_alerts" TO "anon";
GRANT ALL ON TABLE "public"."sos_alerts" TO "authenticated";
GRANT ALL ON TABLE "public"."sos_alerts" TO "service_role";

GRANT ALL ON TABLE "public"."user_profiles" TO "anon";
GRANT ALL ON TABLE "public"."user_profiles" TO "authenticated";
GRANT ALL ON TABLE "public"."user_profiles" TO "service_role";

-- Default privileges
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";

-- Fix for foreign keys that reference auth.users
-- We need to update these to use our custom auth system
DO $$
BEGIN
  -- Only run if the foreign keys exist
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'ai_conversations_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."ai_conversations"
      DROP CONSTRAINT IF EXISTS "ai_conversations_user_id_fkey";
  END IF;
  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'allergies_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."allergies"
      DROP CONSTRAINT IF EXISTS "allergies_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'appointment_chains_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."appointment_chains"
      DROP CONSTRAINT IF EXISTS "appointment_chains_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'appointments_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."appointments"
      DROP CONSTRAINT IF EXISTS "appointments_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'caregiver_access_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."caregiver_access"
      DROP CONSTRAINT IF EXISTS "caregiver_access_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'documents_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."documents"
      DROP CONSTRAINT IF EXISTS "documents_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'emergency_contacts_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."emergency_contacts"
      DROP CONSTRAINT IF EXISTS "emergency_contacts_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'health_metrics_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."health_metrics"
      DROP CONSTRAINT IF EXISTS "health_metrics_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'medication_intakes_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."medication_intakes"
      DROP CONSTRAINT IF EXISTS "medication_intakes_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'medications_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."medications"
      DROP CONSTRAINT IF EXISTS "medications_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'mood_entries_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."mood_entries"
      DROP CONSTRAINT IF EXISTS "mood_entries_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'sos_alerts_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."sos_alerts"
      DROP CONSTRAINT IF EXISTS "sos_alerts_user_id_fkey";
  END IF;

  IF EXISTS (
    SELECT 1 FROM information_schema.table_constraints 
    WHERE constraint_name = 'user_profiles_user_id_fkey'
  ) THEN
    ALTER TABLE ONLY "public"."user_profiles"
      DROP CONSTRAINT IF EXISTS "user_profiles_user_id_fkey";
  END IF;
END
$$;

-- Add foreign keys that reference auth_users instead of auth.users
ALTER TABLE ONLY "public"."ai_conversations"
    ADD CONSTRAINT "ai_conversations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;
ALTER TABLE ONLY "public"."allergies"
    ADD CONSTRAINT "allergies_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointment_chains"
    ADD CONSTRAINT "appointment_chains_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."appointments"
    ADD CONSTRAINT "appointments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."caregiver_access"
    ADD CONSTRAINT "caregiver_access_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."documents"
    ADD CONSTRAINT "documents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."emergency_contacts"
    ADD CONSTRAINT "emergency_contacts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."health_metrics"
    ADD CONSTRAINT "health_metrics_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."medication_intakes"
    ADD CONSTRAINT "medication_intakes_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."medications"
    ADD CONSTRAINT "medications_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."mood_entries"
    ADD CONSTRAINT "mood_entries_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."sos_alerts"
    ADD CONSTRAINT "sos_alerts_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

ALTER TABLE ONLY "public"."user_profiles"
    ADD CONSTRAINT "user_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "public"."auth_users"("id") ON DELETE CASCADE;

RESET ALL;