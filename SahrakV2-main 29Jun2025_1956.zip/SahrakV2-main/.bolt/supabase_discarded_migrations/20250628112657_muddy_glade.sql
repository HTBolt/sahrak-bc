/*
  # Fix Primary Keys and Constraints

  1. Schema Updates
     - Fix primary key constraints for all tables
     - Fix missing comma in appointment_chains table
     - Add primary key constraints to appointment_documents and emergency_contacts
     - Fix RLS policies for anon access

  2. Security
     - Maintain all existing RLS policies
     - Ensure proper foreign key relationships
*/

-- Fix appointment_chains table missing comma
ALTER TABLE IF EXISTS "public"."appointment_chains" 
  DROP COLUMN IF EXISTS "root_appointment_id",
  ADD COLUMN "root_appointment_id" uuid NOT NULL;

-- Add primary key to appointment_documents if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'appointment_documents_pkey' 
    AND conrelid = 'public.appointment_documents'::regclass
  ) THEN
    ALTER TABLE ONLY "public"."appointment_documents"
      ADD CONSTRAINT "appointment_documents_pkey" PRIMARY KEY ("id");
  END IF;
END
$$;

-- Add primary key to emergency_contacts if missing
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'emergency_contacts_pkey' 
    AND conrelid = 'public.emergency_contacts'::regclass
  ) THEN
    ALTER TABLE ONLY "public"."emergency_contacts"
      ADD CONSTRAINT "emergency_contacts_pkey" PRIMARY KEY ("id");
  END IF;
END
$$;

-- Re-add the foreign key for appointment_chains
ALTER TABLE ONLY "public"."appointment_chains"
    ADD CONSTRAINT "appointment_chains_root_appointment_id_fkey" FOREIGN KEY ("root_appointment_id") REFERENCES "public"."appointments"("id") ON DELETE CASCADE;

-- Fix RLS policies for anon access
DO $$
BEGIN
  -- Drop policies that might have incorrect anon access
  DROP POLICY IF EXISTS "Allow authenticated users to delete caregivers" ON "public"."caregivers";
  DROP POLICY IF EXISTS "Allow authenticated users to insert caregivers" ON "public"."caregivers";
  DROP POLICY IF EXISTS "Allow authenticated users to select caregivers" ON "public"."caregivers";
  DROP POLICY IF EXISTS "Allow authenticated users to update caregivers" ON "public"."caregivers";
  DROP POLICY IF EXISTS "Users can manage own SOS alerts" ON "public"."sos_alerts";
  DROP POLICY IF EXISTS "Users can manage own appointment chains" ON "public"."appointment_chains";
  DROP POLICY IF EXISTS "Users can manage own appointment documents" ON "public"."appointment_documents";
  DROP POLICY IF EXISTS "Users can manage own appointments" ON "public"."appointments";
  DROP POLICY IF EXISTS "Users can manage own conversations" ON "public"."ai_conversations";
  DROP POLICY IF EXISTS "Users can manage own documents" ON "public"."documents";
  DROP POLICY IF EXISTS "Users can manage own emergency contacts" ON "public"."emergency_contacts";
  DROP POLICY IF EXISTS "Users can manage own health metrics" ON "public"."health_metrics";
  DROP POLICY IF EXISTS "Users can manage own medication intakes" ON "public"."medication_intakes";
  DROP POLICY IF EXISTS "Users can manage own medications" ON "public"."medications";
  DROP POLICY IF EXISTS "Users can manage own mood entries" ON "public"."mood_entries";
  DROP POLICY IF EXISTS "Users can manage their caregiver access" ON "public"."caregiver_access";
  DROP POLICY IF EXISTS "Users can update related caregivers" ON "public"."caregivers";
  DROP POLICY IF EXISTS "Users can view related caregivers" ON "public"."caregivers";
END
$$;

-- Recreate policies with correct permissions
CREATE POLICY "Allow authenticated users to delete caregivers" ON "public"."caregivers" FOR DELETE TO "authenticated" USING (true);
CREATE POLICY "Allow authenticated users to insert caregivers" ON "public"."caregivers" FOR INSERT TO "authenticated" WITH CHECK (true);
CREATE POLICY "Allow authenticated users to select caregivers" ON "public"."caregivers" FOR SELECT TO "authenticated" USING (true);
CREATE POLICY "Allow authenticated users to update caregivers" ON "public"."caregivers" FOR UPDATE TO "authenticated" USING (true) WITH CHECK (true);
CREATE POLICY "Users can manage own SOS alerts" ON "public"."sos_alerts" TO "authenticated" USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own appointment chains" ON "public"."appointment_chains" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own appointment documents" ON "public"."appointment_documents" TO "authenticated" USING ((EXISTS ( SELECT 1 FROM "public"."appointments" WHERE (("appointments"."id" = "appointment_documents"."appointment_id") AND ("appointments"."user_id" = "auth"."uid"())))));
CREATE POLICY "Users can manage own appointments" ON "public"."appointments" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own conversations" ON "public"."ai_conversations" TO "authenticated" USING (("auth"."uid"() = "user_id")) WITH CHECK (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own documents" ON "public"."documents" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own emergency contacts" ON "public"."emergency_contacts" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own health metrics" ON "public"."health_metrics" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own medication intakes" ON "public"."medication_intakes" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own medications" ON "public"."medications" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage own mood entries" ON "public"."mood_entries" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can manage their caregiver access" ON "public"."caregiver_access" TO "authenticated" USING (("auth"."uid"() = "user_id"));
CREATE POLICY "Users can update related caregivers" ON "public"."caregivers" FOR UPDATE TO "authenticated" USING ((EXISTS ( SELECT 1 FROM "public"."caregiver_access" WHERE (("caregiver_access"."caregiver_id" = "caregivers"."id") AND ("caregiver_access"."user_id" = "auth"."uid"())))));
CREATE POLICY "Users can view related caregivers" ON "public"."caregivers" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1 FROM "public"."caregiver_access" WHERE (("caregiver_access"."caregiver_id" = "caregivers"."id") AND ("caregiver_access"."user_id" = "auth"."uid"())))));